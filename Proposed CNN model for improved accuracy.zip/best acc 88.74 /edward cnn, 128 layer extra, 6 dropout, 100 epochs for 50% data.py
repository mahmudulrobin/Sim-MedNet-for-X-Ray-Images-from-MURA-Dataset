
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers




# HW 1-1
import pylab
import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
import pathlib


import time, datetime

start = datetime.datetime.now()

time.sleep(10)

#new import
import keras
import matplotlib.pyplot as plt
import pathlib
from tensorflow import keras
from keras.layers import Input
from keras import Model
import pylab

import numpy as np
import tensorflow as tf


# # load
# train_data_dir = '/content/drive/MyDrive/Mura_Dataset/MURA-v1.1/train'
# # train_data_dir = './Mura Dataset ML 50% dataset/MURA-v1.1/train'
# train_data_dir = pathlib.Path(train_data_dir)
# image_count_train = len(list(train_data_dir.glob('*/*.jpg')))
#
# test_data_dir = '/content/drive/MyDrive/Mura_Dataset/MURA-v1.1/valid'
# # test_data_dir = './Mura Dataset ML 50% dataset/MURA-v1.1/valid'
# test_data_dir = pathlib.Path(test_data_dir)
# image_count_test = len(list(test_data_dir.glob('*/*.jpg')))

# load
train_data_dir = './Mura Dataset ML 50% dataset/MURA-v1.1/train'
# train_data_dir = './Mura Dataset ML 50% dataset/MURA-v1.1/train'
train_data_dir = pathlib.Path(train_data_dir)
image_count_train = len(list(train_data_dir.glob('*/*.jpg')))

test_data_dir = './Mura Dataset ML 50% dataset/MURA-v1.1/valid'
# test_data_dir = './Mura Dataset ML 50% dataset/MURA-v1.1/valid'
test_data_dir = pathlib.Path(test_data_dir)
image_count_test = len(list(test_data_dir.glob('*/*.jpg')))


# data prep
batch_size = 32
img_height = 128
img_width = 128
trainX = tf.keras.utils.image_dataset_from_directory(train_data_dir, seed=123, image_size=(img_height, img_width), batch_size=batch_size)
testX = tf.keras.utils.image_dataset_from_directory(test_data_dir, seed=123, image_size=(img_height, img_width), batch_size=batch_size)
classes = trainX.class_names
plt.figure(figsize=(10, 10))

# model
totalclasses=(len(classes))

# model
model = tf.keras.Sequential([
  tf.keras.layers.Rescaling(1. / 255),
  tf.keras.layers.Conv2D(32, 3, activation='relu'),
  tf.keras.layers.MaxPooling2D(pool_size=2),
  tf.keras.layers.Dropout(0.2),
  tf.keras.layers.Conv2D(32, 3, activation='relu'),
  tf.keras.layers.MaxPooling2D(pool_size=2),
  tf.keras.layers.Dropout(0.2),
  tf.keras.layers.Conv2D(64, 3, activation='relu'),
  tf.keras.layers.MaxPooling2D(pool_size=2),
  tf.keras.layers.Dropout(0.2),
  tf.keras.layers.Conv2D(64, 3, activation='relu'),
  tf.keras.layers.MaxPooling2D(pool_size=2),
  tf.keras.layers.Dropout(0.2),
  tf.keras.layers.Conv2D(128, 3, activation='relu'),
  tf.keras.layers.MaxPooling2D(pool_size=2),
  tf.keras.layers.Dropout(0.2),
  tf.keras.layers.Flatten(),
  tf.keras.layers.Dense(128, activation='relu'),
  tf.keras.layers.Dense(128, activation='relu'),
  tf.keras.layers.Dense(64, activation='relu'),
  tf.keras.layers.Dropout(0.2),
  tf.keras.layers.Dense(totalclasses)
])

#
# model = tf.keras.Sequential([
#   tf.keras.layers.Rescaling(1. / 255),
#
#   tf.keras.layers.Conv2D(64, 4, activation='relu'),
#   tf.keras.layers.MaxPooling2D(pool_size=2),
#   tf.keras.layers.Dropout(0.2),
#
#   tf.keras.layers.Conv2D(64, 4, activation='relu'),
#   tf.keras.layers.MaxPooling2D(pool_size=2),
#   tf.keras.layers.Dropout(0.2),
#   # tf.keras.layers.Conv2D(64, 3, activation='relu'),
#   # tf.keras.layers.MaxPooling2D(pool_size=2),
#   # tf.keras.layers.Dropout(0.2),
#
#   tf.keras.layers.Conv2D(32, 4, activation='relu'),
#   tf.keras.layers.MaxPooling2D(pool_size=2),
#   tf.keras.layers.Conv2D(32, 4, activation='relu'),
#   tf.keras.layers.MaxPooling2D(pool_size=2),
#
#   tf.keras.layers.Flatten(),
#   tf.keras.layers.Dense(128, activation='relu'),
#   tf.keras.layers.Dense(128, activation='relu'),
#   tf.keras.layers.Dense(64, activation='relu'),
#   tf.keras.layers.Dropout(0.2),
#   tf.keras.layers.Dense(totalclasses)
# ])

# extra optimizer introduced (RMSprop and Adam)
# opt=tf.keras.optimizers.RMSprop(lr=0.001, rho=0.9, epsilon=1e-08,decay=0.0)

model.compile(optimizer='adam', loss=tf.losses.SparseCategoricalCrossentropy(from_logits=True), metrics=['accuracy'])
# model.compile(optimizer=opt, loss=tf.losses.SparseCategoricalCrossentropy(from_logits=True), metrics=['accuracy'])
history = model.fit(trainX, validation_data=testX, epochs=100)

y_vloss = history.history['val_loss']
y_loss = history.history['loss']
y_acc = history.history['accuracy']
y_vacc = history.history['val_accuracy']

fig, (ax1) = plt.subplots(1)
ax1.plot(np.arange(len(y_vloss)), y_vloss, marker='.', c='red')
ax1.plot(np.arange(len(y_loss)), y_loss, marker='.', c='blue')
ax1.grid()
plt.title('Model Loss')
plt.setp(ax1, xlabel='epoch', ylabel='loss')
plt.legend(['test', 'train'], loc='upper left')
plt.savefig("./loss.jpg")
plt.show()

fig, (ax2) = plt.subplots(1)
ax2.plot(np.arange(len(y_vacc)), y_vacc, marker='.', c='red')
ax2.plot(np.arange(len(y_acc)), y_acc, marker='.', c='blue')
ax2.grid()
plt.title('Model Accuracy')
plt.setp(ax2, xlabel='epoch', ylabel='accuracy')
plt.legend(['test', 'train'], loc='upper left')
plt.savefig("./accuracy.jpg")



plt.show()



end = datetime.datetime.now()
diff = (end - start)
datetime.timedelta(seconds=10, microseconds=885206)


diff_seconds = int(diff.total_seconds())
minute_seconds, seconds = divmod(diff_seconds, 60)
hours, minutes = divmod(minute_seconds, 60)
hms = f"{hours}h {minutes}m {seconds}s"
print("\nTotal Running Time for the model: ", hms)